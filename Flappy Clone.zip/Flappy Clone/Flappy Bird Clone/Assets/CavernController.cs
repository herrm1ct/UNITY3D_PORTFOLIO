﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CavernController : MonoBehaviour {

    [SerializeField]
    private static float cavernSpeed = 500;

    [SerializeField]
    private float leftBounds;

    [SerializeField]
    private bool canMove;

    // Use this for initialization
    void Start()
    {
        cavernSpeed = 500f;
    }

    // Update is called once per frame
    void Update () {

        if (canMove)
        {

            // Move Ceiling/Floor Prefab gateSpeed units / second
            this.transform.localPosition = new Vector3(this.transform.localPosition.x - (Time.deltaTime * cavernSpeed), this.transform.localPosition.y, 0);

            //Check if Out of Bounds, and if so, revert to other side of screen
            if (this.transform.localPosition.x <= leftBounds)
            {

                this.transform.localPosition = new Vector3(this.transform.localPosition.x + (-3 * leftBounds), this.transform.localPosition.y, 0);

            }

            //Debug.Log("X: " + this.transform.localPosition.x);


        }



    }

    public void SetCavernSpeed(float s)
    {

        cavernSpeed = s;

    }

    void OnCollisionEnter2D(Collision2D c)
    {

        if (c.gameObject.CompareTag("Player"))
        {
            Debug.Log("Player Collision!");
        }

    }

}
