﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    [SerializeField]
    private float movementSpeed;

    [SerializeField]
    private bool gameStarted;

    [SerializeField]
    private AudioSource jumpSound;

    [SerializeField]
    private AudioSource hitSound;

    [SerializeField]
    private GameObject player;

    [SerializeField]
    private Rigidbody2D playerRigidBody;

    [SerializeField]
    private float jumpAmount;

    [SerializeField]
    private bool canJump;

    [SerializeField]
    private Collider2D playerCollider;

    [SerializeField]
    private GameController gameController;

    [SerializeField]
    private GameObject UIInstructions;

    [SerializeField]
    private GameObject UICounter;

    [SerializeField]
    private GameObject UIGameOver;

    [SerializeField]
    private GateController gate;

    [SerializeField]
    private CavernController cavern;

    // Use this for initialization
    void Start () {

        canJump = false;
        gameStarted = false;
        playerRigidBody.simulated = false;
        UIInstructions.SetActive(true);
        UICounter.SetActive(false);
        UIGameOver.SetActive(false);
		
	}
	
	// Update is called once per frame
	void Update () {

        if (!gameStarted)
        {
            if (Input.GetButtonDown("Jump"))
            {

                //Debug.Log("Jump Pressed");
                canJump = true;
                playerRigidBody.simulated = true;
                playerRigidBody.AddForce(Vector2.up * (jumpAmount / 10f), ForceMode2D.Impulse);
                jumpSound.Play();
                UIInstructions.SetActive(false);
                UICounter.SetActive(true);
                gate.SetGateSpeed(500f);
                gameStarted = true;

            }
        }

        if (canJump)
        {

            if (Input.GetButtonDown("Jump"))
            {

                //Debug.Log("Jump Pressed");

                playerRigidBody.AddForce(Vector2.up * jumpAmount, ForceMode2D.Impulse);
                jumpSound.Play();

            }

        }        

    }

    public void StopPlayer()
    {
        jumpSound.Stop();
        gate.SetGateSpeed(0f);
        cavern.SetCavernSpeed(0f);
        UIGameOver.SetActive(true);
        hitSound.Play();

    }

    //public void OnTriggerEnter2D(Collider2D c)
    //{
    //    Debug.Log("Triggered!");
    //    gameController.IncrementCounter();

    //}

    //public void OnCollisionEnter2D(Collision2D c)
    //{
    //    Debug.Log("Collided!");
    //    gameController.IncrementCounter();

    //}

}
