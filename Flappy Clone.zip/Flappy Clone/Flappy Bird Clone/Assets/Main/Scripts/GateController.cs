﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GateController : MonoBehaviour {

    [SerializeField]
    private static float gateSpeed = 500;

    [SerializeField]
    private float leftBounds;

    [SerializeField]
    private float bottomRange;

    [SerializeField]
    private float topRange;

    [SerializeField]
    private Collider2D gateCounter;

    [SerializeField]
    private GameController gameController;

    [SerializeField]
    private AudioSource counter;

    // Use this for initialization
    void Start () {

        this.gateCounter = GetComponent<Collider2D>();
        gateSpeed = 0;
		
	}

    // Update is called once per frame
    void Update()
    {

        // Move Ceiling/Floor Prefab gateSpeed units / second
        this.transform.localPosition = new Vector3(this.transform.localPosition.x - (Time.deltaTime * gateSpeed), this.transform.localPosition.y, 0);

        //Check if Out of Bounds, and if so, revert to other side of screen
        if (this.transform.localPosition.x <= leftBounds)
        {

            //this.transform.localPosition = new Vector3(this.transform.localPosition.x + (-2.5f * leftBounds), this.transform.localPosition.y, 0);

            this.transform.localPosition = new Vector3(this.transform.localPosition.x + (-2.5f * leftBounds), Random.Range(bottomRange, topRange), 0);

        }

        //Debug.Log("X: " + this.transform.localPosition.x);

    }

    public void SetGateSpeed(float s)
    {

        gateSpeed = s;

    }

    void OnTriggerEnter2D(Collider2D c)
    {

        Debug.Log("Triggered!");

        gameController.IncrementCounter();
        counter.Play();

    }

}
