﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    [SerializeField]
    private Text foregroundCounter;

    [SerializeField]
    private Text backgroundCounter;

    [SerializeField]
    private int currentJumps;

	// Use this for initialization
	void Start () {

        foregroundCounter.text = 0.ToString();
        backgroundCounter.text = 0.ToString();

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void IncrementCounter()
    {

        currentJumps++;
        UpdateUI();

    }

    private void UpdateUI()
    {

        foregroundCounter.text = currentJumps.ToString();
        backgroundCounter.text = currentJumps.ToString();

    }

    public void RestartGame()
    {
        StartCoroutine(ResetScene());
    }

    IEnumerator ResetScene()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("Game", LoadSceneMode.Single);
    }

}
