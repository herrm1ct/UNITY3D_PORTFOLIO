﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuControllerBehavior : MonoBehaviour {

    [SerializeField]
    private AudioSource buttonSelect;

	// Use this for initialization
	void Start () {

        buttonSelect = GetComponent<AudioSource>();
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetButtonDown("Jump"))
        {
            StartGame();
        }
		
	}

    public void StartGame()
    {

        Debug.Log("Button Pressed! Starting game!");
        buttonSelect.Play();
        StartCoroutine(ChangeScene());
        

    }

    IEnumerator ChangeScene()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("Game", LoadSceneMode.Single);
    }

}
