﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHoverMenu : MonoBehaviour {

    [SerializeField]
    private GameObject player;

    [SerializeField]
    private bool down;

    [SerializeField]
    private float speed;

    [SerializeField]
    private float upperBound;

    [SerializeField]
    private float lowerBound;

    [SerializeField]
    private float spread;



	// Use this for initialization
	void Start () {

        upperBound = player.transform.localPosition.y + spread;
        lowerBound = player.transform.localPosition.y - spread;
        
        down = false;
		
	}
	
	// Update is called once per frame
	void Update () {

        MoveBlock(player, speed);
		
	}

    private void MoveBlock(GameObject currentBlock, float speed)
    {

        if (currentBlock.transform.localPosition.y >= upperBound)
        {

            currentBlock.transform.localPosition = new Vector3(currentBlock.transform.localPosition.x, currentBlock.transform.localPosition.y - (Time.deltaTime * speed), 0f);

            down = false;

        }
        else if (currentBlock.transform.localPosition.y <= lowerBound)
        {

            currentBlock.transform.localPosition = new Vector3(currentBlock.transform.localPosition.x, currentBlock.transform.localPosition.y + (Time.deltaTime * speed), 0f);

            down = true;

        }

        if (down)
        {
            currentBlock.transform.localPosition = new Vector3(currentBlock.transform.localPosition.x, currentBlock.transform.localPosition.y + (Time.deltaTime * speed), 0f);
        }
        else if (!down)
        {
            currentBlock.transform.localPosition = new Vector3(currentBlock.transform.localPosition.x , currentBlock.transform.localPosition.y - (Time.deltaTime * speed), 0f);
        }

    }        

}
