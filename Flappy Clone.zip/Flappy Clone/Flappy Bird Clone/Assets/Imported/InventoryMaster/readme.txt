Version 4.6.1:
- recoded and documentated the DragItem Script
- bug fixed where the number of a stack wasn't placed right
- fixed a bug where the slotdesign did not taken from the new slot after you changed the design

Version 4.6.2:
- fixed a bug where you could drag more than one item on a slot
- fixed a bug where you could drag a item on an invisible slot
- added a Craft System

Version 4.6.3:
- FIX: Number of stacking item does not reset after changing inventory settings
- FIX: items are getting updated now, after you changed them in the itemdatabase
- FIX: Tooltip only get displayed when it should be displayed
- FIX: Number of a stack should be placed right now, even if you are splitting the item
- FIX: fixed a building bug
- FIX: fixed where you could have picked up more items than you could
- UPDATE: added a event system which provides consuming, equiping
- UPDATE: added "X" for closing the inventory
- UPDATE: change the general design for a better overview
- UPDATE: changed the item class.

Version 4.6.4
- some bug fixes

Version 4.6.7
- replaced a texture

Version 4.6.8
- Unity 5 ready
- new IM-Manager
- new Input Manager, to handle Keycodes for the inventories
- now you are allowed to create more final items out of an ingredient(Example: 1 wood as an ingridient will give you 2 planks)
- a complete new texture pack
- some bug fixes and some different changes
